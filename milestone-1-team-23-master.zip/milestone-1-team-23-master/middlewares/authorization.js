const { roles } = require('../roles');
const BlockedToken = require('../models/BlockedToken');
const jwt = require('jsonwebtoken');

exports.grantAccess = function (action, resource) {
  return async (req, res, next) => {
    try {
      const permission = roles.can(req.role)[action](resource);
      if (!permission.granted) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
};

exports.allowIfLoggedin = async (req, res, next) => {
  const accessToken = req.get('authorization');
  const blockedToken = await BlockedToken.findOne({ token: accessToken });
  if (blockedToken) {
    return res.status(401).json({
      error: 'You need to log in to perform this action',
    });
  }
  let decodedToken;
  try {
    decodedToken = jwt.verify(accessToken, process.env.JWT_SECRET);
  } catch (error) {
    return res.status(401).json({
      error: 'You need to log in to perform this action',
    });
  }
  req.role = decodedToken.role;
  req.id = decodedToken.id;
  next();
};
