// server/models/Course.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CourseSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      dropDups: true,
    },
    departmentId: {
      type: Schema.Types.ObjectId,
      ref: 'Department',
      required: true,
    },
    courseCoordinatorId: {
      type: String,
      ref: 'AcademicMember',
    },
    courseInstructorIds: [
      {
        type: String,
        ref: 'AcademicMember',
      },
    ],
  },
  { timestamps: true }
);

const Course = mongoose.model('course', CourseSchema);

module.exports = Course;
