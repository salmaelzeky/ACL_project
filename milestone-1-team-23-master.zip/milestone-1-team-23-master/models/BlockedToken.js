// server/models/Course.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BlockedTokenSchema = new Schema(
  {
    token: {
      type: String,
      required: true,
      unique: true,
      dropDups: true,
    },
  },
  { timestamps: true }
);

const BlockedToken = mongoose.model('blockedToken', BlockedTokenSchema);

module.exports = BlockedToken;
