// server/models/HR.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AcademicMemberSchema = new Schema(
  {
    uniId: {
      type: String,
      unique: true,
      required: true,
      dropDups: true,
    },
    email: {
      type: String,
      unique: true,
      required: true,
      dropDups: true,
    },
    password: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    gender: {
      type: String,
      required: true,
      enum: ['male', 'female'],
    },
    salary: {
      type: Number,
      required: true,
    },
    annualLeaves: {
      type: Number,
    },
    usedAnnualLeaves: {
      type: Number,
      default: 0,
    },
    usedAccidentalLeaves: {
      type: Number,
      default: 0,
    },
    usedSickLeaves: {
      type: Number,
      default: 0,
    },
    usedMaternityLeaves: {
      type: Number,
      default: 0,
    },
    usedCompensationLeaves: {
      type: Number,
      default: 0,
    },
    dayOff: {
      type: String,
      enum: ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      required: true,
      default: 'saturday',
    },
    officeId: {
      type: Schema.Types.ObjectId,
      ref: 'Location',
      required: true,
    },
    facultyId: {
      type: Schema.Types.ObjectId,
      ref: 'Faculty',
      required: true,
    },
    departmentId: {
      type: Schema.Types.ObjectId,
      ref: 'Department',
      required: true,
    },
    courseIds: [
      {
        type: Schema.Types.ObjectId,
        ref: 'Course',
      },
    ],
    missingDays: {
      type: Number,
      default: 0,
    },
    missingHours: {
      type: Number,
      default: 0,
    },
    extraHours: {
      type: Number,
      default: 0,
    },
    role: {
      type: String,
      default: 'basic',
      enum: ['basic', 'hod', 'ci', 'co'],
    },
    accessToken: {
      type: String,
    },
  },
  { timestamps: true }
);

const AcademicMember = mongoose.model('academicMember', AcademicMemberSchema);

module.exports = AcademicMember;
