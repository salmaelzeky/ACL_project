// server/models/Location.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const LocationSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      dropDups: true,
    },
    type: {
      type: String,
      required: true,
      enum: ['lab', 'room', 'hall', 'office'],
    },
    fullCapacity: {
      type: Number,
      required: true,
    },
    currentCapacity: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

const Location = mongoose.model('location', LocationSchema);

module.exports = Location;
