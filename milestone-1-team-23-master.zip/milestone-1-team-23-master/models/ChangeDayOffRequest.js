// server/models/ChangeDayOffRequest.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ChangeDayOffRequestSchema = new Schema(
  {
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    headOfDepartmentId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    dayOff: {
      type: String,
      enum: ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'accepted', 'rejected'],
      default: 'pending',
    },
  },
  { timestamps: true }
);

const ChangeDayOffRequest = mongoose.model('changeDayOffRequest', ChangeDayOffRequestSchema);

module.exports = ChangeDayOffRequest;
