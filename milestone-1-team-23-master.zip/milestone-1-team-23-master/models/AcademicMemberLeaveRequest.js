// server/models/AcademicMemberLeaveRequest.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AcademicMemberLeaveRequestSchema = new Schema(
  {
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    headOfDepartmentId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    requestedDate: {
      type: Date,
      required: true,
    },
    type: {
      type: String,
      enum: ['annual', 'accidental', 'sick', 'maternity', 'compensation'],
      required: true,
    },
    reason: {
      type: String,
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'accepted', 'rejected'],
      default: 'pending',
    },
  },
  { timestamps: true }
);

const AcademicMemberLeaveRequest = mongoose.model('academicMemberLeaveRequest', AcademicMemberLeaveRequestSchema);

module.exports = AcademicMemberLeaveRequest;
