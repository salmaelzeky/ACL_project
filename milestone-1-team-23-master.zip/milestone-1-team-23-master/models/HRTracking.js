// server/models/HRTracking.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const HRTrackingSchema = new Schema(
  {
    hrId: {
      type: String,
      ref: 'HR',
      required: true,
    },
    trackingType: {
      type: String,
      enum: ['in', 'out'],
      required: true,
    },
  },
  { timestamps: true }
);

const HRTracking = mongoose.model('hrTracking', HRTrackingSchema);

module.exports = HRTracking;
