// server/models/HR.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const HRSchema = new Schema(
  {
    uniId: {
      type: String,
      unique: true,
      required: true,
      dropDups: true,
    },
    email: {
      type: String,
      unique: true,
      required: true,
      dropDups: true,
    },
    password: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    gender: {
      type: String,
      required: true,
      enum: ['male', 'female'],
    },
    salary: {
      type: Number,
      required: true,
    },
    annualLeaves: {
      type: Number,
    },
    accidentalLeaves: {
      type: Number,
    },
    sickLeaves: {
      type: Number,
    },
    maternityLeaves: {
      type: Number,
    },
    usedAnnualLeaves: {
      type: Number,
    },
    usedAccidentalLeaves: {
      type: Number,
    },
    usedSickLeaves: {
      type: Number,
    },
    usedMaternityLeaves: {
      type: Number,
    },
    dayOff: {
      type: String,
      required: true,
      enum: ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
      default: 'saturday',
    },
    officeId: {
      type: Schema.Types.ObjectId,
      ref: 'Location',
      required: true,
    },
    missingDays: {
      type: Number,
      default: 0,
    },
    missingHours: {
      type: Number,
      default: 0,
    },
    extraHours: {
      type: Number,
      default: 0,
    },
    role: {
      type: String,
      default: 'hr',
      enum: ['hr'],
    },
    accessToken: {
      type: String,
    },
  },
  { timestamps: true }
);

const HR = mongoose.model('hr', HRSchema);

module.exports = HR;
