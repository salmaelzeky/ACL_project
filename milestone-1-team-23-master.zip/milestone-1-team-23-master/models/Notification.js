// server/models/Notification.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const NotificationSchema = new Schema(
  {
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    requestId: {
      type: Schema.Types.ObjectId,
      required: true,
    },
    type: {
      type: String,
      enum: ['replacement', 'dayOff', 'leave', 'slotLinking'],
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['accepted', 'rejected'],
    },
  },
  { timestamps: true }
);

const Notification = mongoose.model('notification', NotificationSchema);

module.exports = Notification;
