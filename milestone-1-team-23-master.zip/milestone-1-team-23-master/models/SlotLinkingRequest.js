// server/models/SlotLinkingRequest.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SlotLinkingRequestSchema = new Schema(
  {
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    courseCoordinatorId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    slotId: {
      type: Schema.Types.ObjectId,
      ref: 'Slot',
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'accepted', 'rejected'],
      default: 'pending',
    },
  },
  { timestamps: true }
);

const SlotLinkingRequest = mongoose.model('slotLinkingRequest', SlotLinkingRequestSchema);

module.exports = SlotLinkingRequest;
