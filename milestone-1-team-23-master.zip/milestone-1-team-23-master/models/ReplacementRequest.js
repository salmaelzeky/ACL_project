// server/models/ReplacementRequest.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ReplacementRequestSchema = new Schema(
  {
    senderAcademicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    receiverAcademicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    slotId: {
      type: Schema.Types.ObjectId,
      ref: 'Slot',
      required: true,
    },
    status: {
      type: String,
      required: true,
      enum: ['pending', 'accepted', 'rejected'],
      default: 'pending',
    },
    date: {
      type: Date,
      required: true,
    },
  },
  { timestamps: true }
);

const ReplacementRequest = mongoose.model('replacementRequest', ReplacementRequestSchema);

module.exports = ReplacementRequest;
