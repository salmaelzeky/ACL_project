// server/models/AcademicMemberTracking.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const AcademicMemberTrackingSchema = new Schema(
  {
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
      required: true,
    },
    trackingType: {
      type: String,
      enum: ['in', 'out'],
      required: true,
    },
  },
  { timestamps: true }
);

const AcademicMemberTracking = mongoose.model('academicMemberTracking', AcademicMemberTrackingSchema);

module.exports = AcademicMemberTracking;
