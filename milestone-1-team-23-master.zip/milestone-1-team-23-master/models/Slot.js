// server/models/Slot.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const SlotSchema = new Schema(
  {
    courseId: {
      type: Schema.Types.ObjectId,
      ref: 'Course',
      required: true,
    },
    academicMemberId: {
      type: String,
      ref: 'AcademicMember',
    },
    substituteAcademicMemberId: {
      type: String,
      ref: 'AcademicMember',
    },
    day: {
      type: String,
      required: true,
      enum: ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
    },
    number: {
      type: Number,
      required: true,
    },
    locationId: {
      type: Schema.Types.ObjectId,
      ref: 'Location',
      required: true,
    },
  },
  { timestamps: true }
);

const Slot = mongoose.model('slot', SlotSchema);

module.exports = Slot;
