// server/models/Department.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const DepartmentSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
      dropDups: true,
    },
    facultyId: {
      type: Schema.Types.ObjectId,
      ref: 'Faculty',
      required: true,
    },
    headOfDepartmentId: {
      type: String,
      ref: 'AcademicMember',
    },
  },
  { timestamps: true }
);

const Department = mongoose.model('department', DepartmentSchema);

module.exports = Department;
