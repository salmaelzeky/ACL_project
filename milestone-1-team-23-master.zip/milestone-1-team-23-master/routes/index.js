const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const hrController = require('../controllers/hrController');
const academicMemberController = require('../controllers/academicMemberController');
const locationController = require('../controllers/locationController');
const facultyController = require('../controllers/facultyController');
const departmentController = require('../controllers/departmentController');
const slotController = require('../controllers/slotController');
const courseController = require('../controllers/courseController');
const changeDayOffRequestController = require('../controllers/changeDayOffRequestController');
const slotLinkingRequestController = require('../controllers/slotLinkingRequestController');
const replacementRequestController = require('../controllers/replacementRequestController');
const academicMemberLeaveRequestController = require('../controllers/academicMemberLeaveRequestController');

const { grantAccess, allowIfLoggedin } = require('../middlewares/authorization');
// done
router.get('/getAllHRs', allowIfLoggedin, hrController.getAllHRs);
router.get('/getAllAcademicMembers', allowIfLoggedin, academicMemberController.getAllAcademicMembers);
// done
router.get('/getAllLocations', allowIfLoggedin, locationController.getAllLocations);
// done
router.get('/getAllFaculties', allowIfLoggedin, facultyController.getAllFaculties);
// done
router.get('/getAllDepartments', allowIfLoggedin, departmentController.getAllDepartments);
router.get('/getAllCourses', allowIfLoggedin, courseController.getAllCourses);
router.get('/getAllSlots', allowIfLoggedin, slotController.getAllSlots);
router.get('/getAllNotifications', allowIfLoggedin, userController.getAllNotifications);
// done
// HR can add a new staff member to the system. For all staff members, HR should add id, name, email, salary and office location.
router.post('/user', allowIfLoggedin, userController.addUser);
// done
// Log in with a unique email and a password
router.post('/login', userController.login);
// done
// Log out from the system.
router.post('/logout', allowIfLoggedin, userController.logout);
// done
// View their profile.
router.get('/hr/:hrId', allowIfLoggedin, hrController.getHR);
// done
router.get('/academicMember/:academicMemberId', allowIfLoggedin, academicMemberController.getAcademicMember);
// done
// Update their profile except for the id and the name. Academic members can’t update their salary, faculty and department.
router.put('/hr/:hrId', allowIfLoggedin, hrController.updateHR);
// done
router.put('/academicMember/:academicMemberId', allowIfLoggedin, academicMemberController.updateAcademicMember);
// done
// Delete Users
router.delete('/hr/:hrId', allowIfLoggedin, hrController.deleteHR);
// done
router.delete('/academicMember/:academicMemberId', allowIfLoggedin, academicMemberController.deleteAcademicMember);

// done
// Reset Password
router.post('/resetPassword', allowIfLoggedin, userController.resetPassword);
// done
// Check in
router.post('/checkIn', allowIfLoggedin, userController.checkIn);
// done
// Check out
router.post('/checkOut', allowIfLoggedin, userController.checkOut);
// done
// View Missing Days
router.get('/getMissingDaysAM', allowIfLoggedin, academicMemberController.getMissingDays);
// done
router.get('/getMissingDaysHR', allowIfLoggedin, hrController.getMissingDays);
// done
// View Missing Hours
router.get('/getMissingHoursAM', allowIfLoggedin, academicMemberController.getMissingHours);
// done
router.get('/getMissingHoursHR', allowIfLoggedin, hrController.getMissingHours);
// done
// View extra Hours
router.get('/getExtraHoursAM', allowIfLoggedin, academicMemberController.getExtraHours);
// done
router.get('/getExtraHoursHR', allowIfLoggedin, hrController.getExtraHours);
// done
// View attendance records
router.get('/getAttendanceRecordsAM', allowIfLoggedin, academicMemberController.getAttendanceRecords);
// done
router.get('/getAttendanceRecordsHR', allowIfLoggedin, hrController.getAttendanceRecords);
// done
// View attendance records By Month
router.get('/getAttendanceRecordsAM/:month', allowIfLoggedin, academicMemberController.getAttendanceRecordsByMonth);
// done
router.get('/getAttendanceRecordsHR/:month', allowIfLoggedin, hrController.getAttendanceRecordsByMonth);
// done
// View attendance records by hr
router.get(
  '/getAttendanceRecordsAMByHR/:academicMemberId',
  allowIfLoggedin,
  grantAccess('readAny', 'attendance'),
  academicMemberController.getAttendanceRecordsByHR
);
// done
router.get(
  '/getAttendanceRecordsHRByHR/:hrId',
  allowIfLoggedin,
  grantAccess('readAny', 'attendance'),
  hrController.getAttendanceRecordsByHR
);
// done
// Check in for hr by hr
router.post('/checkInHR/:hrId', allowIfLoggedin, grantAccess('createAny', 'check'), hrController.checkInByHR);
// done
// Check out for hr by hr
router.post('/checkOutHR/:hrId', allowIfLoggedin, grantAccess('createAny', 'check'), hrController.checkOutByHR);
// done
// Check in for academic member by hr
router.post(
  '/checkInAM/:academicMemberId',
  allowIfLoggedin,
  grantAccess('createAny', 'check'),
  academicMemberController.checkInByHR
);
// done
// Check out for academic member by hr
router.post(
  '/checkOutAm/:academicMemberId',
  allowIfLoggedin,
  grantAccess('createAny', 'check'),
  academicMemberController.checkOutByHR
);
// done
// Check out for academic member by hr
router.get(
  '/staffWithMissingAttendance',
  allowIfLoggedin,
  grantAccess('readAny', 'attendance'),
  hrController.staffWithMissingAttendance
);

// Location Routes
// done
router.post('/addLocation', allowIfLoggedin, grantAccess('createAny', 'location'), locationController.addLocation);
// done
router.put(
  '/location/:locationId',
  allowIfLoggedin,
  grantAccess('updateAny', 'location'),
  locationController.updateLocation
);
// done
router.delete(
  '/location/:locationId',
  allowIfLoggedin,
  grantAccess('deleteAny', 'location'),
  locationController.deleteLocation
);

// Faculty Routes
// done
router.post('/addFaculty', allowIfLoggedin, grantAccess('createAny', 'location'), facultyController.addFaculty);
// done
router.put(
  '/faculty/:facultyId',
  allowIfLoggedin,
  grantAccess('updateAny', 'faculty'),
  facultyController.updateFaculty
);
// done
router.delete(
  '/faculty/:facultyId',
  allowIfLoggedin,
  grantAccess('deleteAny', 'faculty'),
  facultyController.deleteFaculty
);

// Department Routes
// done
router.post(
  '/addDepartment',
  allowIfLoggedin,
  grantAccess('createAny', 'department'),
  departmentController.addDepartment
);
// done

router.put(
  '/department/:departmentId',
  allowIfLoggedin,
  grantAccess('updateAny', 'department'),
  departmentController.updateDepartment
);
// done
router.delete(
  '/department/:departmentId',
  allowIfLoggedin,
  grantAccess('deleteAny', 'department'),
  departmentController.deleteDepartment
);

router.get('/viewStaffInADepartmentByCI', allowIfLoggedin, departmentController.viewStaffInADepartmentByCI);

router.get('/viewStaffInADepartmentByHOD', allowIfLoggedin, departmentController.viewStaffInADepartmentByHOD);
// done
router.get('/viewDayOffInADepartmentByHOD', allowIfLoggedin, departmentController.viewDayOffInADepartmentByHOD);

// Course Routes

router.post('/addCourse', allowIfLoggedin, grantAccess('createAny', 'department'), courseController.addCourse);

router.put('/course/:courseId', allowIfLoggedin, grantAccess('updateAny', 'course'), courseController.updateCourse);

router.delete('/course/:courseId', allowIfLoggedin, grantAccess('deleteAny', 'course'), courseController.deleteCourse);

router.post('/getCourseCoverage', allowIfLoggedin, courseController.getCourseCoverage);

router.post('/viewStaffInACourseByCI', allowIfLoggedin, courseController.viewStaffInACourseByCI);

router.post('/assignCourseCoordinator', allowIfLoggedin, courseController.assignCourseCoordinator);

router.post('/assignCourseToAM', allowIfLoggedin, courseController.assignCourseToAM);

router.post('/deleteCourseToAM', allowIfLoggedin, courseController.deleteCourseToAM);

// done
router.get('/getAllCoursesCoverageInDepartment', allowIfLoggedin, courseController.getAllCoursesCoverageInDepartment);
// done
router.post('/assignCourseInstructor', allowIfLoggedin, courseController.assignCourseInstructor);
// done
router.post('/deleteCourseInstructor', allowIfLoggedin, courseController.deleteCourseInstructor);

router.post('/viewStaffInACourseByHOD', allowIfLoggedin, courseController.viewStaffInACourseByHOD);

// Academic members functionality
// done
// View Schedule
router.get('/getSchedule', allowIfLoggedin, academicMemberController.getSchedule);
// done
// Send change day off requests
router.post('/sendChangeDayOffRequest', allowIfLoggedin, changeDayOffRequestController.sendChangeDayOffRequest);
// done
// View change day off requests
router.post('/viewChangeDayOffRequests', allowIfLoggedin, changeDayOffRequestController.viewChangeDayOffRequests);

// Cancel slot linking requests
router.post(
  '/cancelChangeDayOffRequest/:changeDayOffRequestId',
  allowIfLoggedin,
  changeDayOffRequestController.cancelChangeDayOffRequest
);
// done
// View change day off requests by HOD
router.get(
  '/viewChangeDayOffRequestsByHOD',
  allowIfLoggedin,
  changeDayOffRequestController.viewChangeDayOffRequestsByHOD
);
// done
// reject change day off requests by HOD
router.post(
  '/acceptChangeDayOffRequestsByHOD/:changeDayOffRequestId',
  allowIfLoggedin,
  changeDayOffRequestController.acceptChangeDayOffRequestsByHOD
);
// done
// reject change day off requests by HOD
router.post(
  '/rejectChangeDayOffRequestsByHOD/:changeDayOffRequestId',
  allowIfLoggedin,
  changeDayOffRequestController.rejectChangeDayOffRequestsByHOD
);
// done
// Send leave requests
router.post('/sendLeaveRequest', allowIfLoggedin, academicMemberLeaveRequestController.sendLeaveRequest);
// done
// View leave requests
router.post('/viewLeaveRequests', allowIfLoggedin, academicMemberLeaveRequestController.viewLeaveRequests);
// done
// Cancel leave requests
router.post(
  '/cancelLeaveRequest/:leaveRequestId',
  allowIfLoggedin,
  academicMemberLeaveRequestController.cancelLeaveRequest
);
// done
// accept leave requests
router.post(
  '/acceptLeaveRequestByHOD/:leaveRequestId',
  allowIfLoggedin,
  academicMemberLeaveRequestController.acceptLeaveRequestsByHOD
);
// done
// accept leave requests
router.post(
  '/rejectLeaveRequestByHOD/:leaveRequestId',
  allowIfLoggedin,
  academicMemberLeaveRequestController.rejectLeaveRequestsByHOD
);
// done
// View leave requests By HOD
router.get('/viewLeaveRequestsByHOD', allowIfLoggedin, academicMemberLeaveRequestController.viewLeaveRequestsByHOD);

// Slot Linking Requests Routes

// Send slot linking requests
router.post('/sendSlotLinkingRequest', allowIfLoggedin, slotLinkingRequestController.sendSlotLinkingRequest);

// View slot linking requests
router.post('/viewSlotLinkingRequests', allowIfLoggedin, slotLinkingRequestController.viewSlotLinkingRequests);

// Cancel slot linking requests
router.post(
  '/cancelSlotLinkingRequest/:slotLinkingRequestId',
  allowIfLoggedin,
  slotLinkingRequestController.cancelSlotLinkingRequest
);

// View slot linking requests by coordinator
router.get(
  '/viewSlotLinkingRequestsByCoordinator',
  allowIfLoggedin,
  slotLinkingRequestController.viewSlotLinkingRequestsByCoordinator
);

// Accept slot linking requests
router.post(
  '/acceptSlotLinkingRequest/:slotLinkingRequestId',
  allowIfLoggedin,
  slotLinkingRequestController.acceptSlotLinkingRequest
);

// Reject slot linking requests
router.post(
  '/rejectSlotLinkingRequest/:slotLinkingRequestId',
  allowIfLoggedin,
  slotLinkingRequestController.rejectSlotLinkingRequest
);

// Replacement Requests Routes

// View replacement requests
router.post('/viewReplacementRequests', allowIfLoggedin, replacementRequestController.viewReplacementRequests);

// Send replacement requests
router.post('/sendReplacementRequest', allowIfLoggedin, replacementRequestController.sendReplacementRequest);

// Cancel replacement requests
router.post(
  '/cancelReplacementRequest/:replacementRequestId',
  allowIfLoggedin,
  replacementRequestController.cancelReplacementRequest
);

// Accept replacement requests
router.post(
  '/acceptReplacementRequest/:replacementRequestId',
  allowIfLoggedin,
  replacementRequestController.acceptReplacementRequest
);

// Reject replacement requests
router.post(
  '/rejectReplacementRequest/:replacementRequestId',
  allowIfLoggedin,
  replacementRequestController.rejectReplacementRequest
);

// Slot Routes

router.post('/addSlot', allowIfLoggedin, slotController.addSlot);

router.put('/slot/:slotId', allowIfLoggedin, slotController.updateSlot);

router.delete('/slot/:slotId', allowIfLoggedin, slotController.deleteSlot);

router.post('/viewSlotsInACourseByCI', allowIfLoggedin, slotController.viewSlotsInACourseByCI);

router.post('/viewSlotsInACourseByHOD', allowIfLoggedin, slotController.viewSlotsInACourseByHOD);

router.post('/assignSlotToAM', allowIfLoggedin, slotController.assignSlotToAM);

module.exports = router;
