const Faculty = require('../models/Faculty');

exports.getAllFaculties = async (req, res, next) => {
  try {
    const allFaculties = await Faculty.find({});

    return res.status(200).json({
      faculties: allFaculties,
    });
  } catch (error) {
    next(error);
  }
};

exports.addFaculty = async (req, res, next) => {
  try {
    const { name } = req.body;

    const newFaculty = new Faculty({ name });
    await newFaculty.save();
    res.json({
      data: newFaculty,
      message: 'The faculty has been created Successfully',
    });
  } catch (error) {
    next(error);
  }
};

exports.updateFaculty = async (req, res, next) => {
  try {
    const facultyId = req.params.facultyId;
    const { name } = req.body;
    await Faculty.findByIdAndUpdate(facultyId, { name }, { omitUndefined: true });
    const faculty = await Faculty.findById(facultyId);
    return res.status(200).json({
      data: faculty,
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteFaculty = async (req, res, next) => {
  try {
    const facultyId = req.params.facultyId;
    await Faculty.findByIdAndDelete(facultyId);
    return res.status(200).json({
      data: null,
      message: 'Faculty has been deleted',
    });
  } catch (error) {
    next(error);
  }
};
