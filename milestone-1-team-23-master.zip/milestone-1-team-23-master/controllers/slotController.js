const AcademicMember = require('../models/AcademicMember');
const Course = require('../models/Course');
const Slot = require('../models/Slot');
const Location = require('../models/Location');
const Department = require('../models/Department');

exports.getAllSlots = async (req, res, next) => {
  try {
    const allSlots = await Slot.find({});

    return res.status(200).json({
      slots: allSlots,
    });
  } catch (error) {
    next(error);
  }
};

exports.addSlot = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const course = await Course.findOne({ courseCoordinatorId: req.id });

      if (!course) {
        return res.status(401).json({
          error: 'You are not a coordinator in any course',
        });
      }

      const { day, number, locationId } = req.body;

      const location = await Location.findById(locationId);

      if (!location) {
        return res.status(401).json({
          error: 'No Location with this id',
        });
      }

      if (location.type === 'office') {
        return res.status(405).json({
          error: 'This location is an office, please choose another location',
        });
      }

      const conflictedSlotLocation = await Slot.findOne({ day, number, locationId });

      if (conflictedSlotLocation) {
        return res.status(401).json({
          error: 'There is a slot in the same location at the same time',
        });
      }

      const newSlot = new Slot({ courseId: course._id, day, number, locationId });

      await newSlot.save();

      res.json({
        data: newSlot,
        message: 'The slot has been created Successfully',
      });
      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.updateSlot = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const slotId = req.params.slotId;

      const slot = await Slot.findById(slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'No Slot with that id',
        });
      }

      const course = await Course.findOne({ courseCoordinatorId: req.id });

      if (!course) {
        return res.status(401).json({
          error: 'You are not a coordinator in any course',
        });
      }

      if (!course._id.equals(slot.courseId)) {
        return res.status(401).json({
          error: 'You are not a coordinator in that slot course',
        });
      }

      const { day, number, locationId } = req.body;

      const location = await Location.findById(locationId);

      if (!location) {
        return res.status(401).json({
          error: 'No Location with this id',
        });
      }

      if (location.type === 'office') {
        return res.status(405).json({
          error: 'This location is an office, please choose another location',
        });
      }

      await Slot.findByIdAndUpdate(slotId, { day, number, locationId }, { omitUndefined: true });

      const updatedSlot = await Slot.findById(slotId);

      return res.status(200).json({
        data: updatedSlot,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteSlot = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({ uniId: academicMemberId });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const slotId = req.params.slotId;

      const slot = await Slot.findById(slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'No Slot with that id',
        });
      }

      const course = await Course.findOne({ courseCoordinatorId: academicMemberId });

      if (!course) {
        return res.status(401).json({
          error: 'You are not a coordinator in any course',
        });
      }

      if (!course._id.equals(slot.courseId)) {
        return res.status(401).json({
          error: 'You are not a coordinator in that slot course',
        });
      }

      await Slot.findByIdAndDelete(slotId);

      return res.status(200).json({
        data: null,
        message: 'Slot has been deleted',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewSlotsInACourseByCI = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }

      const allSlots = await Slot.find({ courseId: course._id });

      return res.status(200).json({
        slots: allSlots,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.assignSlotToAM = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { academicMemberId, slotId } = req.body;

      const slot = await Slot.findById(slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'No Slot with that id',
        });
      }

      const course = await Course.findById(slot.courseId);

      if (!course.courseInstructorIds || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in that course',
        });
      }

      const assignedAcademicMember = await AcademicMember.findOne({ uniId: academicMemberId });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (!assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = [slot.courseId];
      } else {
        assignedAcademicMember.courseIds.push(slot.courseId);
      }

      await assignedAcademicMember.save();

      await Slot.findByIdAndUpdate(slotId, { academicMemberId });

      return res.status(200).json({
        message: 'The assignment has been done',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewSlotsInACourseByHOD = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const course = await Course.findById(req.body.courseId);

      if (!course) {
        return res.status(401).json({
          error: 'No course with that id',
        });
      }

      const allSlots = await Slot.find({ courseId: course._id });

      return res.status(200).json({
        slots: allSlots,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};
