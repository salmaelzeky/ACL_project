const HR = require('../models/HR');
const Location = require('../models/Location');
const BlockedToken = require('../models/BlockedToken');
const HRTracking = require('../models/HRTracking');
const isEmail = require('validator/lib/isEmail');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const AcademicMember = require('../models/AcademicMember');

async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

exports.getAllHRs = async (req, res, next) => {
  try {
    if (req.role === 'hr') {
      const allHRs = await HR.find({});

      return res.status(200).json({
        hrs: allHRs,
      });
    } else {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.addHR = async (req, res, next) => {
  try {
    const { email, name, gender, officeId, salary } = req.body;

    if (!isEmail(email)) {
      return res.status(401).json({
        error: 'Please Enter an email in the right format',
      });
    }

    const location = await Location.findById(officeId);

    if (location.fullCapacity <= location.currentCapacity) {
      return res.status(405).json({
        error: 'This location is full, please choose another location',
      });
    }

    if (location.type !== 'office') {
      return res.status(405).json({
        error: 'This location is not an office, please choose another location',
      });
    }

    const hashedPassword = await hashPassword('123456');
    let count = await HR.countDocuments({});

    const uniId = 'hr-' + ++count;

    const dayOff = 'saturday';

    const newHR = new HR({
      email,
      password: hashedPassword,
      role: 'hr',
      name,
      uniId,
      gender,
      officeId,
      salary,
      dayOff,
    });

    const accessToken = jwt.sign({ id: newHR.uniId, role: newHR.role }, process.env.JWT_SECRET);
    newHR.accessToken = accessToken;
    await newHR.save();

    ++location.currentCapacity;
    await location.save();
    res.json({
      data: newHR,
      message: 'This HR has been successfully created',
    });
  } catch (error) {
    next(error);
  }
};

exports.getHR = async (req, res, next) => {
  const hrId = req.params.hrId;

  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: hrId });

      if (!hr) {
        return res.status(401).json({
          error: 'Hr does not exist',
        });
      }

      return res.status(200).json({
        data: hr,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.updateHR = async (req, res, next) => {
  try {
    if (req.role === 'hr') {
      if (req.body.dayOff || req.body.name || req.body.uniId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (req.id === req.params.hrId) {
        if (req.body.salary) {
          return res.status(401).json({
            error: "You don't have enough permission to perform this action",
          });
        }
      }

      if (req.id !== req.params.hrId) {
        if (req.body.password) {
          return res.status(401).json({
            error: "You don't have enough permission to perform this action",
          });
        }
      }

      const { email, password, gender, officeId, salary } = req.body;

      if (email && !isEmail(email)) {
        return res.status(401).json({
          error: 'Please Enter an email in the right format',
        });
      }

      const hrId = req.params.hrId;

      let newLocation = null;
      let oldLocation = null;

      if (officeId) {
        newLocation = await Location.findById(officeId);

        if (!newLocation) {
          return res.status(401).json({
            error: 'No Location with this id',
          });
        }

        if (newLocation.fullCapacity <= newLocation.currentCapacity) {
          return res.status(405).json({
            error: 'This location is full, please choose another location',
          });
        }

        if (newLocation.type !== 'office') {
          return res.status(405).json({
            error: 'This location is not an office, please choose another location',
          });
        }

        const hr = await HR.findOne({ uniId: hrId });

        oldLocation = await Location.findById(hr.officeId);

        if (newLocation._id.equals(oldLocation._id)) {
          return res.status(405).json({
            error: 'Please choose a new office cause this one is your office',
          });
        }
      }

      if (password) {
        const hashedPassword = await hashPassword(password);
        await HR.findOneAndUpdate(
          { uniId: hrId },
          { email, hashedPassword, gender, officeId, salary },
          { omitUndefined: true }
        );
      } else {
        await HR.findOneAndUpdate({ uniId: hrId }, { email, gender, officeId, salary }, { omitUndefined: true });
      }

      if (officeId) {
        ++newLocation.currentCapacity;
        await newLocation.save();
        --oldLocation.currentCapacity;
        await oldLocation.save();
      }

      const hr = await HR.findOne({ uniId: hrId });

      return res.status(200).json({
        data: hr,
      });
    } else {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteHR = async (req, res, next) => {
  try {
    if (req.role === 'hr') {
      const hrId = req.params.hrId;
      const hr = await HR.findOne({ uniId: hrId });

      const newBlockedToken = new BlockedToken({
        token: hr.accessToken,
      });

      let token = await BlockedToken.findOne({ token: hr.accessToken });
      if (!token) {
        await newBlockedToken.save();
      }

      await HR.findOneAndDelete({ uniId: hrId });

      return res.status(200).json({
        data: null,
        message: 'HR has been deleted',
      });
    } else {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.checkInByHR = async (req, res, next) => {
  try {
    const hrId = req.params.hrId;
    if (req.id === hrId) {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
    const hr = await HR.findOne({ uniId: hrId });
    if (hr) {
      if (!req.body.date) {
        return res.status(405).json({
          error: 'please set a date',
        });
      }

      let date = new Date(req.body.date);

      if (date.toLocaleDateString() === 'Invalid Date') {
        return res.status(405).json({
          error: 'please set a date a right date',
        });
      }

      date.setDate(date.getDate() + 1);

      const hrTracking = new HRTracking({
        hrId: hrId,
        trackingType: 'in',
        createdAt: date,
      });
      await hrTracking.save();
      return res.status(200).json({
        message: 'You have successfully added this checked in',
      });
    } else {
      return res.status(405).json({
        error: 'No hr with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.checkOutByHR = async (req, res, next) => {
  try {
    const hrId = req.params.hrId;
    if (req.id === hrId) {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
    const hr = await HR.findOne({ uniId: hrId });
    if (hr) {
      if (!req.body.date) {
        return res.status(405).json({
          error: 'please set a date',
        });
      }

      let date = new Date(req.body.date);

      if (date.toLocaleDateString() === 'Invalid Date') {
        return res.status(405).json({
          error: 'please set a date a right date',
        });
      }

      date.setDate(date.getDate() + 1);

      const hrTracking = new HRTracking({
        hrId: hrId,
        trackingType: 'out',
        createdAt: date,
      });
      await hrTracking.save();
      return res.status(200).json({
        message: 'You have successfully added this checked out',
      });
    } else {
      return res.status(405).json({
        error: 'No hr with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.getMissingDays = async (req, res, next) => {
  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: req.id });

      if (!hr) {
        return res.status(401).json({
          error: 'HR does not exist',
        });
      }

      return res.status(200).json({
        missingDays: hr.missingDays,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getMissingHours = async (req, res, next) => {
  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: req.id });

      if (!hr) {
        return res.status(401).json({
          error: 'HR does not exist',
        });
      }

      return res.status(200).json({
        missingHours: hr.missingHours,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getExtraHours = async (req, res, next) => {
  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: req.id });

      if (!hr) {
        return res.status(401).json({
          error: 'HR does not exist',
        });
      }

      return res.status(200).json({
        extraHours: hr.extraHours,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecords = async (req, res, next) => {
  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: req.id });

      if (!hr) {
        return res.status(401).json({
          error: 'HR does not exist',
        });
      }

      const attendanceRecords = await HRTracking.find({ hrId: req.id });

      return res.status(200).json({
        attendanceRecords: attendanceRecords,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecordsByMonth = async (req, res, next) => {
  if (req.role === 'hr') {
    try {
      const hr = await HR.findOne({ uniId: req.id });

      if (!hr) {
        return res.status(401).json({
          error: 'HR does not exist',
        });
      }

      const attendanceRecords = await HRTracking.find({ hrId: req.id });

      let filteredAttendanceRecords = attendanceRecords.filter((e) => {
        let month = e.createdAt.getMonth();
        month++;
        return month === +req.params.month;
      });

      return res.status(200).json({
        attendanceRecords: filteredAttendanceRecords,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecordsByHR = async (req, res, next) => {
  try {
    const hrId = req.params.hrId;

    const hr = await HR.findOne({ uniId: hrId });
    if (hr) {
      const attendanceRecords = await HRTracking.find({ hrId: hrId });

      return res.status(200).json({
        attendanceRecords: attendanceRecords,
      });
    } else {
      return res.status(405).json({
        error: 'No hr with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.staffWithMissingAttendance = async (req, res, next) => {
  try {
    const hrs = await HR.find({
      $or: [{ missingDays: { $ne: 0 } }, { missingHours: { $ne: 0 } }],
    });
    const academicMembers = await AcademicMember.find({
      $or: [{ missingDays: { $ne: 0 } }, { missingHours: { $ne: 0 } }],
    });

    return res.status(200).json({
      hrs: hrs,
      academicMembers: academicMembers,
    });
  } catch (error) {
    next(error);
  }
};
