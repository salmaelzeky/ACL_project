const AcademicMember = require("../models/AcademicMember");
const AcademicMemberLeaveRequest = require("../models/AcademicMemberLeaveRequest");
const Notification = require("../models/Notification");
const Department = require("../models/Department");

exports.sendLeaveRequest = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const academicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      let { type, date, reason } = req.body;
      const status = "pending";

      if (!req.body.reason) {
        reason = "N/A";
      }

      if (!type) {
        return res.status(405).json({
          error: "please set a type",
        });
      }

      if (!date) {
        return res.status(405).json({
          error: "please set a date",
        });
      }

      let requestedDate = new Date(req.body.date);

      if (requestedDate.toLocaleDateString() === "Invalid Date") {
        return res.status(405).json({
          error: "please set a date a right date",
        });
      }

      requestedDate.setDate(requestedDate.getDate() + 1);

      const department = await Department.findById(academicMember.departmentId);

      if (!department) {
        return res.status(401).json({
          error: "No department of this member",
        });
      }

      const headOfDepartmentId = department.headOfDepartmentId;

      let currentDate = new Date();

      currentDate.setDate(currentDate.getDate() + 1);

      let newRequest = null;

      if (type === "annual") {
        if (
          requestedDate > currentDate &&
          (requestedDate.getFullYear() > currentDate.getFullYear() ||
            requestedDate.getMonth() > currentDate.getMonth() ||
            requestedDate.getDate() !== currentDate.getDate())
        ) {
          if (academicMember.annualLeaves >= 1) {
            newRequest = new AcademicMemberLeaveRequest({
              academicMemberId,
              headOfDepartmentId,
              requestedDate,
              type,
              reason,
              status,
            });
          } else {
            return res.status(401).json({
              error: "You do not have enough annual leaves",
            });
          }
        } else {
          return res.status(401).json({
            error: "You cannot submit an annual leave after its date",
          });
        }
      } else if (type === "accidental") {
        if (academicMember.annualLeaves >= 1) {
          if (academicMember.usedAccidentalLeaves < 6) {
            newRequest = new AcademicMemberLeaveRequest({
              academicMemberId,
              headOfDepartmentId,
              requestedDate,
              type,
              reason,
              status,
            });
          } else {
            return res.status(401).json({
              error: "You do not have enough accidental leaves",
            });
          }
        } else {
          return res.status(401).json({
            error: "You do not have enough annual leaves",
          });
        }
      } else if (type === "sick") {
        const diffTime = Math.abs(currentDate - requestedDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays <= 3) {
          newRequest = new AcademicMemberLeaveRequest({
            academicMemberId,
            headOfDepartmentId,
            requestedDate,
            type,
            reason,
            status,
          });
        } else {
          return res.status(401).json({
            error: "You cannot submit a sick leave after 3 days from its date",
          });
        }
      } else if (type === "maternity") {
        if (academicMember.gender === "female") {
          if (reason !== "N/A") {
            newRequest = new AcademicMemberLeaveRequest({
              academicMemberId,
              headOfDepartmentId,
              requestedDate,
              type,
              reason,
              status,
            });
          } else {
            return res.status(401).json({
              error: "Please provide a reason",
            });
          }
        } else {
          return res.status(401).json({
            error: "You cannot submit a maternity leave",
          });
        }
      } else if (type === "compensation") {
        if (reason !== "N/A") {
          console.log("beep boop:", reason);
          newRequest = new AcademicMemberLeaveRequest({
            academicMemberId,
            headOfDepartmentId,
            requestedDate,
            type,
            reason,
            status,
          });
        } else {
          return res.status(401).json({
            error: "Please provide a reason",
          });
        }
      } else {
        return res.status(401).json({
          error: "Please provide a valid type",
        });
      }

      await newRequest.save();

      return res.status(200).json({
        request: newRequest,
        message: "The request has been successfully made",
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewLeaveRequests = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      let status = null;

      if (req.body.status) {
        status = req.body.status;
      }

      let requests = null;

      if (!status) {
        requests = await AcademicMemberLeaveRequest.find({
          academicMemberId: req.id,
        });
      } else if (status === "accepted") {
        requests = await AcademicMemberLeaveRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else if (status === "rejected") {
        requests = await AcademicMemberLeaveRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else if (status === "pending") {
        requests = await AcademicMemberLeaveRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else {
        return res.status(401).json({
          error: "Please enter a valid status",
        });
      }

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.cancelLeaveRequest = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const senderAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: senderAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      const requestId = req.params.leaveRequestId;

      const academicMemberLeaveRequest = await AcademicMemberLeaveRequest.findById(
        requestId
      );

      if (!academicMemberLeaveRequest) {
        return res.status(401).json({
          error: "No request with this id",
        });
      }

      if (
        senderAcademicMemberId !== academicMemberLeaveRequest.academicMemberId
      ) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (academicMemberLeaveRequest.status !== "pending") {
        return res.status(401).json({
          error: "You cannot cancel this request",
        });
      }

      await AcademicMemberLeaveRequest.findByIdAndDelete(requestId);

      return res.status(200).json({
        message: "The request has been successfully cancelled",
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewLeaveRequestsByHOD = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: "You are not the head of the department",
        });
      }

      let requests = await AcademicMemberLeaveRequest.find({
        headOfDepartmentId: req.id,
      });

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.acceptLeaveRequestsByHOD = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: "You are not the head of the department",
        });
      }

      const requestId = req.params.leaveRequestId;

      const academicMemberLeaveRequest = await AcademicMemberLeaveRequest.findById(
        requestId
      );

      if (!academicMemberLeaveRequest) {
        return res.status(401).json({
          error: "No request with this id",
        });
      }

      if (academicMemberLeaveRequest.headOfDepartmentId !== req.id) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (academicMemberLeaveRequest.status !== "pending") {
        return res.status(401).json({
          error: "You cannot accept this request",
        });
      }

      const academicMemberId = academicMemberLeaveRequest.academicMemberId;

      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: "No academic member with that id",
        });
      }

      const type = academicMemberLeaveRequest.type;

      if (type === "annual") {
        if (assignedAcademicMember.annualLeaves >= 1) {
          ++assignedAcademicMember.usedAnnualLeaves;
          --assignedAcademicMember.annualLeaves;
        } else {
          return res.status(401).json({
            error: "He does not have enough annual leaves",
          });
        }
      } else if (type === "accidental") {
        if (assignedAcademicMember.annualLeaves >= 1) {
          if (assignedAcademicMember.usedAccidentalLeaves < 6) {
            ++assignedAcademicMember.usedAnnualLeaves;
            --assignedAcademicMember.annualLeaves;
            ++assignedAcademicMember.usedAccidentalLeaves;
          } else {
            return res.status(401).json({
              error: "He does not have enough accidental leaves",
            });
          }
        } else {
          return res.status(401).json({
            error: "He does not have enough annual leaves",
          });
        }
      } else if (type === "sick") {
        ++assignedAcademicMember.usedSickLeaves;
      } else if (type === "maternity") {
        if (assignedAcademicMember.gender === "female") {
          ++assignedAcademicMember.usedMaternityLeaves;
        } else {
          return res.status(401).json({
            error: "He cannot submit a maternity leave",
          });
        }
      } else if (type === "compensation") {
        ++assignedAcademicMember.usedCompensationLeaves;
      } else {
        return res.status(401).json({
          error: "Please provide a valid type",
        });
      }

      await assignedAcademicMember.save();

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: "leave",
        status: "accepted",
      });

      await newNotification.save();

      academicMemberLeaveRequest.status = "accepted";

      await academicMemberLeaveRequest.save();

      return res.status(200).json({
        message: "The request has been successfully accepted",
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.rejectLeaveRequestsByHOD = async (req, res, next) => {
  if (req.role !== "hr") {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: "Academic member does not exist",
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: "You are not the head of the department",
        });
      }

      const requestId = req.params.leaveRequestId;

      const academicMemberLeaveRequest = await AcademicMemberLeaveRequest.findById(
        requestId
      );

      if (!academicMemberLeaveRequest) {
        return res.status(401).json({
          error: "No request with this id",
        });
      }

      if (academicMemberLeaveRequest.headOfDepartmentId !== req.id) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (academicMemberLeaveRequest.status !== "pending") {
        return res.status(401).json({
          error: "You cannot reject this request",
        });
      }

      const academicMemberId = academicMemberLeaveRequest.academicMemberId;

      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: "No academic member with that id",
        });
      }

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: "leave",
        status: "rejected",
      });

      await newNotification.save();

      academicMemberLeaveRequest.status = "rejected";

      academicMemberLeaveRequest.rejectionReason = req.body.rejectionReason;

      await academicMemberLeaveRequest.save();

      return res.status(200).json({
        message: "The request has been successfully rejected",
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};
