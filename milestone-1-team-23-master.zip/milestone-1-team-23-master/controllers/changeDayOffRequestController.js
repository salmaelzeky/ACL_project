const AcademicMember = require('../models/AcademicMember');
const Department = require('../models/Department');
const Notification = require('../models/Notification');
const ChangeDayOffRequest = require('../models/ChangeDayOffRequest');

exports.sendChangeDayOffRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({ uniId: academicMemberId });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { dayOff } = req.body;
      const status = 'pending';

      if (!dayOff) {
        return res.status(405).json({
          error: 'please set a day off',
        });
      }

      const department = await Department.findById(academicMember.departmentId);

      if (!department) {
        return res.status(401).json({
          error: 'No department of this member',
        });
      }

      const headOfDepartmentId = department.headOfDepartmentId;

      const newRequest = new ChangeDayOffRequest({
        academicMemberId,
        headOfDepartmentId,
        dayOff,
        status,
      });

      await newRequest.save();

      return res.status(200).json({
        request: newRequest,
        message: 'The request has been successfully made',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewChangeDayOffRequests = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      let status = null;

      if (req.body.status) {
        status = req.body.status;
      }

      let requests = null;

      if (!status) {
        requests = await ChangeDayOffRequest.find({ academicMemberId: req.id });
      } else if (status === 'accepted') {
        requests = await ChangeDayOffRequest.find({ academicMemberId: req.id, status });
      } else if (status === 'rejected') {
        requests = await ChangeDayOffRequest.find({ academicMemberId: req.id, status });
      } else if (status === 'pending') {
        requests = await ChangeDayOffRequest.find({ academicMemberId: req.id, status });
      } else {
        return res.status(401).json({
          error: 'Please enter a valid status',
        });
      }

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.cancelChangeDayOffRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const senderAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({ uniId: senderAcademicMemberId });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.changeDayOffRequestId;

      const changeDayOffRequest = await ChangeDayOffRequest.findById(requestId);

      if (!changeDayOffRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (senderAcademicMemberId !== changeDayOffRequest.academicMemberId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (changeDayOffRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot cancel this request',
        });
      }

      await ChangeDayOffRequest.findByIdAndDelete(requestId);

      return res.status(200).json({
        message: 'The request has been successfully cancelled',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewChangeDayOffRequestsByHOD = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      let requests = await ChangeDayOffRequest.find({ headOfDepartmentId: req.id });

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.acceptChangeDayOffRequestsByHOD = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const requestId = req.params.changeDayOffRequestId;

      const changeDayOffRequest = await ChangeDayOffRequest.findById(requestId);

      if (!changeDayOffRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (changeDayOffRequest.headOfDepartmentId !== req.id) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (changeDayOffRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot accept this request',
        });
      }

      const academicMemberId = changeDayOffRequest.academicMemberId;

      const assignedAcademicMember = await AcademicMember.findOne({ uniId: academicMemberId });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      assignedAcademicMember.dayOff = changeDayOffRequest.dayOff;

      await assignedAcademicMember.save();

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'dayOff',
        status: 'accepted',
      });

      await newNotification.save();

      changeDayOffRequest.status = 'accepted';

      await changeDayOffRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully accepted',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.rejectChangeDayOffRequestsByHOD = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const requestId = req.params.changeDayOffRequestId;

      const changeDayOffRequest = await ChangeDayOffRequest.findById(requestId);

      if (!changeDayOffRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (changeDayOffRequest.headOfDepartmentId !== req.id) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (changeDayOffRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot reject this request',
        });
      }

      const academicMemberId = changeDayOffRequest.academicMemberId;

      const assignedAcademicMember = await AcademicMember.findOne({ uniId: academicMemberId });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'dayOff',
        status: 'rejected',
      });

      await newNotification.save();

      changeDayOffRequest.status = 'rejected';

      await changeDayOffRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully rejected',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};
