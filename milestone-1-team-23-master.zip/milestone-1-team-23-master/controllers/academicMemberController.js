const AcademicMember = require('../models/AcademicMember');
const Location = require('../models/Location');
const BlockedToken = require('../models/BlockedToken');
const AcademicMemberTracking = require('../models/AcademicMemberTracking');
const Slot = require('../models/Slot');
const isEmail = require('validator/lib/isEmail');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

exports.getAllAcademicMembers = async (req, res, next) => {
  try {
    const allAcademicMembers = await AcademicMember.find({});

    return res.status(200).json({
      academicMembers: allAcademicMembers,
    });
  } catch (error) {
    next(error);
  }
};

exports.addAcademicMember = async (req, res, next) => {
  try {
    if (req.body.courseId) {
      return res.status(401).json({
        error: "You can't set a course for this user, as you don't have enough permissions",
      });
    }
    const { email, name, gender, officeId, facultyId, departmentId, salary } = req.body;

    if (!isEmail(email)) {
      return res.status(401).json({
        error: 'Please Enter an email in the right format',
      });
    }

    const location = await Location.findById(officeId);

    if (location.fullCapacity <= location.currentCapacity) {
      return res.status(405).json({
        error: 'This location is full, please choose another location',
      });
    }

    if (location.type !== 'office') {
      return res.status(405).json({
        error: 'This location is not an office, please choose another location',
      });
    }

    const hashedPassword = await hashPassword('123456');
    let count = await AcademicMember.countDocuments({});

    const uniId = 'ac-' + ++count;

    const dayOff = 'saturday';

    const newAcademicMember = new AcademicMember({
      email,
      password: hashedPassword,
      role: 'basic',
      name,
      uniId,
      gender,
      officeId,
      facultyId,
      departmentId,
      salary,
      dayOff,
    });

    const accessToken = jwt.sign({ id: newAcademicMember.uniId, role: newAcademicMember.role }, process.env.JWT_SECRET);
    newAcademicMember.accessToken = accessToken;
    await newAcademicMember.save();
    ++location.currentCapacity;
    await location.save();
    res.json({
      data: newAcademicMember,
      message: 'This academic member has been successfully created',
    });
  } catch (error) {
    next(error);
  }
};

exports.getAcademicMember = async (req, res, next) => {
  const academicMemberId = req.params.academicMemberId;
  try {
    const academicMember = await AcademicMember.findOne({
      uniId: academicMemberId,
    });

    if (!academicMember) {
      return res.status(401).json({
        error: 'Academic member does not exist',
      });
    }

    return res.status(200).json({
      data: academicMember,
    });
  } catch (error) {
    next(error);
  }
  return;
};

exports.updateAcademicMember = async (req, res, next) => {
  try {
    if (req.role !== 'hr' && req.id === req.params.academicMemberId) {
      if (
        req.body.dayOff ||
        req.body.name ||
        req.body.uniId ||
        req.salary ||
        req.facultyId ||
        req.departmentId ||
        req.courseId
      ) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      const { email, password, gender, officeId } = req.body;

      if (email && !isEmail(email)) {
        return res.status(401).json({
          error: 'Please Enter an email in the right format',
        });
      }

      const academicMemberId = req.params.academicMemberId;

      let newLocation = null;
      let oldLocation = null;

      if (officeId) {
        newLocation = await Location.findById(officeId);

        if (!newLocation) {
          return res.status(401).json({
            error: 'No Location with this id',
          });
        }

        if (newLocation.fullCapacity <= newLocation.currentCapacity) {
          return res.status(405).json({
            error: 'This location is full, please choose another location',
          });
        }

        if (newLocation.type !== 'office') {
          return res.status(405).json({
            error: 'This location is not an office, please choose another location',
          });
        }

        const academicMember = await academicMember.findOne({
          uniId: academicMemberId,
        });

        oldLocation = await Location.findById(academicMember.officeId);

        if (newLocation._id.equals(oldLocation._id)) {
          return res.status(405).json({
            error: 'Please choose a new office cause this one is your office',
          });
        }
      }

      const hashedPassword = await hashPassword(password);

      await AcademicMember.findOneAndUpdate(
        { uniId: academicMemberId },
        { email, hashedPassword, gender, officeId },
        { omitUndefined: true }
      );

      if (officeId) {
        ++location.currentCapacity;
        await location.save();
        --oldLocation.currentCapacity;
        await oldLocation.save();
      }

      const academicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      return res.status(200).json({
        data: academicMember,
      });
    } else if (req.role === 'hr') {
      if (req.body.uniId || req.facultyId || req.departmentId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      const { email, gender, officeId, salary } = req.body;

      if (email && !isEmail(email)) {
        return res.status(401).json({
          error: 'Please Enter an email in the right format',
        });
      }

      const academicMemberId = req.params.academicMemberId;

      if (officeId) {
        let location = await Location.findById(officeId);

        if (!location) {
          return res.status(401).json({
            error: 'No Location with this id',
          });
        }

        if (location.fullCapacity <= location.currentCapacity) {
          return res.status(405).json({
            error: 'This location is full, please choose another location',
          });
        }

        if (location.type !== 'office') {
          return res.status(405).json({
            error: 'This location is not an office, please choose another location',
          });
        }
        ++location.currentCapacity;
        await location.save();

        const academicMember = await AcademicMember.findOne({
          uniId: academicMemberId,
        });

        location = await Location.findById(academicMember.officeId);
        --location.currentCapacity;
        await location.save();
      }
      await AcademicMember.findOneAndUpdate(
        { uniId: academicMemberId },
        { email, gender, officeId, salary },
        { omitUndefined: true }
      );
      const academicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      return res.status(200).json({
        data: academicMember,
      });
    } else {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.deleteAcademicMember = async (req, res, next) => {
  try {
    if (req.role === 'hr') {
      const academicMemberId = req.params.academicMemberId;
      const academicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      const newBlockedToken = new BlockedToken({
        token: academicMember.accessToken,
      });

      let token = await BlockedToken.findOne({
        token: academicMember.accessToken,
      });

      if (!token) {
        await newBlockedToken.save();
      }

      await AcademicMember.findOneAndDelete({ uniId: academicMemberId });

      return res.status(200).json({
        data: null,
        message: 'Academic member has been deleted',
      });
    } else {
      return res.status(401).json({
        error: "You don't have enough permission to perform this action",
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.checkInByHR = async (req, res, next) => {
  try {
    const academicMemberId = req.params.academicMemberId;

    const academicMember = await AcademicMember.findOne({
      uniId: academicMemberId,
    });
    if (academicMember) {
      if (!req.body.date) {
        return res.status(405).json({
          error: 'please set a date',
        });
      }

      let date = new Date(req.body.date);

      if (date.toLocaleDateString() === 'Invalid Date') {
        return res.status(405).json({
          error: 'please set a date a right date',
        });
      }

      date.setDate(date.getDate() + 1);

      const academicMemberTracking = new AcademicMemberTracking({
        academicMemberId: academicMemberId,
        trackingType: 'in',
        createdAt: date,
      });
      await academicMemberTracking.save();
      return res.status(200).json({
        message: 'You have successfully added this checked in',
      });
    } else {
      return res.status(405).json({
        error: 'No academic member with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.checkOutByHR = async (req, res, next) => {
  try {
    const academicMemberId = req.params.academicMemberId;

    const academicMember = await AcademicMember.findOne({
      uniId: academicMemberId,
    });
    if (academicMember) {
      if (!req.body.date) {
        return res.status(405).json({
          error: 'please set a date',
        });
      }

      let date = new Date(req.body.date);

      if (date.toLocaleDateString() === 'Invalid Date') {
        return res.status(405).json({
          error: 'please set a date a right date',
        });
      }

      date.setDate(date.getDate() + 1);

      const academicMemberTracking = new AcademicMemberTracking({
        academicMemberId: academicMemberId,
        trackingType: 'out',
        createdAt: date,
      });
      await academicMemberTracking.save();
      return res.status(200).json({
        message: 'You have successfully added this checked out',
      });
    } else {
      return res.status(405).json({
        error: 'No academic member with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.getMissingDays = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      return res.status(200).json({
        missingDays: academicMember.missingDays,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getMissingHours = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      return res.status(200).json({
        missingHours: academicMember.missingHours,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getExtraHours = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      return res.status(200).json({
        extraHours: academicMember.extraHours,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecords = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const attendanceRecords = await AcademicMemberTracking.find({
        academicMemberId: req.id,
      });

      return res.status(200).json({
        attendanceRecords: attendanceRecords,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecordsByMonth = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const attendanceRecords = await AcademicMemberTracking.find({
        academicMemberId: req.id,
      });

      let filteredAttendanceRecords = attendanceRecords.filter((e) => {
        let month = e.createdAt.getMonth();
        month++;
        return month === +req.params.month;
      });

      return res.status(200).json({
        attendanceRecords: filteredAttendanceRecords,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.getAttendanceRecordsByHR = async (req, res, next) => {
  try {
    const academicMemberId = req.params.academicMemberId;

    const academicMember = await AcademicMember.findOne({
      uniId: academicMemberId,
    });
    if (academicMember) {
      const attendanceRecords = await AcademicMemberTracking.find({
        academicMemberId: academicMemberId,
      });

      return res.status(200).json({
        attendanceRecords: attendanceRecords,
      });
    } else {
      return res.status(405).json({
        error: 'No academic member with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.getSchedule = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const schedule = await Slot.find({
        $or: [{ academicMemberId: req.id }, { substituteAcademicMemberId: req.id }],
      });

      return res.status(200).json({
        schedule: schedule,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};
