const generator = require('generate-password');
const HR = require('../models/HR');
const AcademicMember = require('../models/AcademicMember');
const BlockedToken = require('../models/BlockedToken');
const HRTracking = require('../models/HRTracking');
const AcademicMemberTracking = require('../models/AcademicMemberTracking');
const Notification = require('../models/Notification');

const isEmail = require('validator/lib/isEmail');
const hrController = require('../controllers/hrController');
const academicMemberController = require('../controllers/academicMemberController');

const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

async function validatePassword(plainPassword, hashedPassword) {
  return await bcrypt.compare(plainPassword, hashedPassword);
}

async function hashPassword(password) {
  return await bcrypt.hash(password, 10);
}

exports.getAllNotifications = async (req, res, next) => {
  try {
    const userId = req.id;

    const allNotifications = await Notification.find({
      academicMemberId: userId,
    });

    return res.status(200).json({
      notifications: allNotifications,
    });
  } catch (error) {
    next(error);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password, role } = req.body;
    if (!isEmail(email)) {
      return res.status(401).json({
        error: 'Please Enter an email in the right format',
      });
    }
    let user = null;

    user = (await AcademicMember.findOne({ email })) || (await HR.findOne({ email }));

    if (!user) {
      return res.status(401).json({
        error: 'Email does not exist',
      });
    }

    const validPassword = await validatePassword(password, user.password);

    if (!validPassword) {
      return res.status(401).json({
        error: 'Password is not correct',
      });
    }

    let message = null;

    if (password === '123456') {
      message = 'Please change your password';
    }

    const accessToken = jwt.sign({ id: user.uniId, role: user.role }, process.env.JWT_SECRET);

    if (role === 'hr') {
      await HR.findByIdAndUpdate(user._id, { accessToken });
    } else {
      await AcademicMember.findByIdAndUpdate(user._id, { accessToken });
    }

    return res.status(200).json({
      data: { email: user.email, role: user.role, id: user.uniId },
      accessToken,
      message,
    });
  } catch (error) {
    next(error);
  }
};

exports.addUser = async (req, res, next) => {
  if (req.body.role === 'hr') {
    hrController.addHR(req, res, next);
  } else {
    academicMemberController.addAcademicMember(req, res, next);
  }
};

exports.logout = async (req, res, next) => {
  try {
    let user = null;
    const userId = req.id;
    if (req.role === 'hr') {
      user = await HR.findOne({ uniId: userId });
    } else {
      user = await AcademicMember.findOne({ uniId: userId });
    }

    const newBlockedToken = new BlockedToken({
      token: user.accessToken,
    });

    await newBlockedToken.save();

    return res.status(200).json({
      message: 'You have successfully logged out',
    });
  } catch (error) {
    next(error);
  }
};

exports.resetPassword = async (req, res, next) => {
  try {
    let user = null;
    const userId = req.id;
    if (req.role === 'hr') {
      user = await HR.findOne({ uniId: userId });
    } else {
      user = await AcademicMember.findOne({ uniId: userId });
    }
    const newPassWord = generator.generate({
      length: 6,
      numbers: true,
      uppercase: false,
      symbols: false,
    });
    const hashedPassword = await hashPassword(newPassWord);

    if (user) {
      user.password = hashedPassword;

      await user.save();

      return res.status(200).json({
        data: { newPassWord: newPassWord },
      });
    } else {
      return res.status(405).json({
        error: 'No user with this id',
      });
    }
  } catch (error) {
    next(error);
  }
};

exports.checkIn = async (req, res, next) => {
  try {
    let user = null;
    const userId = req.id;
    if (req.role === 'hr') {
      user = await HR.findOne({ uniId: userId });
      if (user) {
        const hrTracking = new HRTracking({ hrId: userId, trackingType: 'in' });
        await hrTracking.save();
      }
    } else {
      user = await AcademicMember.findOne({ uniId: userId });
      if (user) {
        const academicMemberTracking = new AcademicMemberTracking({
          academicMemberId: userId,
          trackingType: 'in',
        });
        await academicMemberTracking.save();
      }
    }

    if (!user) {
      return res.status(405).json({
        error: 'No user with this id',
      });
    }

    return res.status(200).json({
      message: 'You have successfully checked in',
    });
  } catch (error) {
    next(error);
  }
};

exports.checkOut = async (req, res, next) => {
  try {
    let user = null;
    const userId = req.id;
    if (req.role === 'hr') {
      user = await HR.findOne({ uniId: userId });
      if (user) {
        const hrTracking = new HRTracking({
          hrId: userId,
          trackingType: 'out',
        });
        await hrTracking.save();
      }
    } else {
      user = await AcademicMember.findOne({ uniId: userId });
      if (user) {
        const academicMemberTracking = new AcademicMemberTracking({
          academicMemberId: userId,
          trackingType: 'out',
        });
        await academicMemberTracking.save();
      }
    }

    if (!user) {
      return res.status(405).json({
        error: 'No user with this id',
      });
    }

    return res.status(200).json({
      message: 'You have successfully checked out',
    });
  } catch (error) {
    next(error);
  }
};
