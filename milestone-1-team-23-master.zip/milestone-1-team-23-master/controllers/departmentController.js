const AcademicMember = require('../models/AcademicMember');
const Department = require('../models/Department');

exports.getAllDepartments = async (req, res, next) => {
  try {
    const allDepartments = await Department.find({});

    return res.status(200).json({
      departments: allDepartments,
    });
  } catch (error) {
    next(error);
  }
};

exports.addDepartment = async (req, res, next) => {
  try {
    const { name, facultyId, headOfDepartmentId } = req.body;

    if (headOfDepartmentId) {
      let academicMember = await AcademicMember.findOne({ uniId: headOfDepartmentId });
      if (!academicMember) {
        return res.status(401).json({
          error: 'No Academic member with that id',
        });
      }
    }

    const newDepartment = new Department({ name, facultyId, headOfDepartmentId });
    await newDepartment.save();
    res.json({
      data: newDepartment,
      message: 'The department has been created Successfully',
    });
  } catch (error) {
    next(error);
  }
};

exports.updateDepartment = async (req, res, next) => {
  try {
    const departmentId = req.params.departmentId;

    const { name, facultyId, headOfDepartmentId } = req.body;

    if (headOfDepartmentId) {
      let academicMember = await AcademicMember.findOne({ uniId: headOfDepartmentId });
      if (!academicMember) {
        return res.status(401).json({
          error: 'No Academic member with that id',
        });
      }
    }

    await Department.findByIdAndUpdate(departmentId, { name, facultyId, headOfDepartmentId }, { omitUndefined: true });
    const department = await Department.findById(departmentId);
    return res.status(200).json({
      data: department,
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteDepartment = async (req, res, next) => {
  try {
    const departmentId = req.params.departmentId;
    await Department.findByIdAndDelete(departmentId);
    return res.status(200).json({
      data: null,
      message: 'Department has been deleted',
    });
  } catch (error) {
    next(error);
  }
};

exports.viewStaffInADepartmentByCI = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const allCourses = await Course.find({});

      let course = allCourses.filter((e) => {
        return e.courseInstructorIds && e.courseInstructorIds.indexOf(req.id) >= 0;
      });

      if (!course && course.length === 0) {
        return res.status(401).json({
          error: 'You are not a course instructor in any course',
        });
      }

      const allAcademicMembers = await AcademicMember.find({ departmentId: academicMember.departmentId });

      return res.status(200).json({
        academicMembers: allAcademicMembers,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewStaffInADepartmentByHOD = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const allAcademicMembers = await AcademicMember.find({ departmentId: academicMember.departmentId });

      return res.status(200).json({
        academicMembers: allAcademicMembers,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewStaffInADepartmentByHOD = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const allAcademicMembers = await AcademicMember.find({ departmentId: academicMember.departmentId });

      return res.status(200).json({
        academicMembers: allAcademicMembers,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewDayOffInADepartmentByHOD = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({ headOfDepartmentId: req.id });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const allAcademicMembers = await AcademicMember.find({ departmentId: academicMember.departmentId }).select(
        'dayOff'
      );

      return res.status(200).json({
        academicMembers: allAcademicMembers,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};
