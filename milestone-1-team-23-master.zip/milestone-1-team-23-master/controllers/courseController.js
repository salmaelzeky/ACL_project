const AcademicMember = require('../models/AcademicMember');
const Course = require('../models/Course');
const Department = require('../models/Department');
const Slot = require('../models/Slot');

exports.getAllCourses = async (req, res, next) => {
  try {
    const allCourses = await Course.find({});

    return res.status(200).json({
      courses: allCourses,
    });
  } catch (error) {
    next(error);
  }
};

exports.addCourse = async (req, res, next) => {
  try {
    const { name, departmentId } = req.body;

    const newCourse = new Course({ name, departmentId });
    await newCourse.save();
    res.json({
      data: newCourse,
      message: 'The course has been created Successfully',
    });
  } catch (error) {
    next(error);
  }
};

exports.updateCourse = async (req, res, next) => {
  try {
    const courseId = req.params.courseId;
    const { name, departmentId } = req.body;
    await Course.findByIdAndUpdate(courseId, { name, departmentId }, { omitUndefined: true });
    const course = await Course.findById(courseId);
    return res.status(200).json({
      data: course,
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteCourse = async (req, res, next) => {
  try {
    const courseId = req.params.courseId;
    await Course.findByIdAndDelete(courseId);
    return res.status(200).json({
      data: null,
      message: 'Course has been deleted',
    });
  } catch (error) {
    next(error);
  }
};

exports.getCourseCoverage = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }

      const slotsOccupied = await Slot.find({
        courseId: course._id,
        academicMemberId: { $ne: null },
      });

      const allSlots = await Slot.find({ courseId: course._id });

      const courseCoverage = (slotsOccupied.length / allSlots.length) * 100;

      return res.status(200).json({
        courseCoverage,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewStaffInACourseByCI = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }

      const allAcademicMembers = await AcademicMember.find({});

      const filteredAcademicMembers = allAcademicMembers.filter((e) => {
        return e.courseIds && e.courseIds.indexOf(req.body.courseId) >= 0;
      });

      return res.status(200).json({
        academicMembers: filteredAcademicMembers,
      });
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.assignCourseCoordinator = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { academicMemberId, courseId } = req.body;

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }
      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (!assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = [courseId];
      } else {
        assignedAcademicMember.courseIds.push(courseId);
      }

      await assignedAcademicMember.save();

      await Course.findByIdAndUpdate(courseId, {
        courseCoordinatorId: assignedAcademicMember.uniId,
      });

      return res.status(200).json({
        message: 'The assignment has been done',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.assignCourseToAM = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { academicMemberId, courseId } = req.body;

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }

      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (!assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = [courseId];
      } else {
        assignedAcademicMember.courseIds.push(courseId);
      }

      await assignedAcademicMember.save();

      return res.status(200).json({
        message: 'The assignment has been done',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteCourseToAM = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { academicMemberId, courseId } = req.body;

      const course = await Course.findById(req.body.courseId);

      if (!course || course.courseInstructorIds.indexOf(req.id) === -1) {
        return res.status(401).json({
          error: 'You are not a course instructor in the course you are in',
        });
      }

      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = assignedAcademicMember.courseIds.filter(function (ele) {
          return ele != courseId;
        });
      }
      await assignedAcademicMember.save();

      return res.status(200).json({
        message: 'The assignment has been deleted',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.getAllCoursesCoverageInDepartment = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const courses = await Course.find({ departmentId: department._id });

      const coursesCoverage = [];

      for (let i = 0; i < courses.length; i++) {
        let course = courses[i];

        let slotsOccupied = await Slot.find({
          courseId: course._id,
          academicMemberId: { $ne: null },
        });

        let allSlots = await Slot.find({ courseId: course._id });

        let courseCoverage = (slotsOccupied.length / allSlots.length) * 100;

        coursesCoverage.push({ courseId: course._id, courseCoverage });
      }

      return res.status(200).json({
        coursesCoverage,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.assignCourseInstructor = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const { academicMemberId, courseId } = req.body;

      const course = await Course.findById(courseId);

      if (!course) {
        return res.status(401).json({
          error: 'No course with that id',
        });
      }
      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (!course.courseInstructorIds) {
        course.courseInstructorIds = [assignedAcademicMember.uniId];
      } else {
        course.courseInstructorIds.push(assignedAcademicMember.uniId);
      }

      await course.save();

      if (!assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = [courseId];
      } else {
        assignedAcademicMember.courseIds.push(courseId);
      }

      await assignedAcademicMember.save();

      return res.status(200).json({
        message: 'The assignment has been done',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteCourseInstructor = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const { academicMemberId, courseId } = req.body;

      const course = await Course.findById(courseId);

      if (!course) {
        return res.status(401).json({
          error: 'No course with that id',
        });
      }
      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      if (course.courseInstructorIds) {
        course.courseInstructorIds = course.courseInstructorIds.filter(function (ele) {
          return ele != assignedAcademicMember.uniId;
        });
      }

      await course.save();

      return res.status(200).json({
        message: 'The assignment has been deleted',
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};

exports.viewStaffInACourseByHOD = async (req, res, next) => {
  try {
    if (req.role !== 'hr') {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const department = await Department.findOne({
        headOfDepartmentId: req.id,
      });

      if (!department) {
        return res.status(401).json({
          error: 'You are not the head of the department',
        });
      }

      const course = await Course.findOne({ _id: req.body.courseId });

      if (!course) {
        return res.status(401).json({
          error: 'This course does not exist',
        });
      }

      const allAcademicMembers = await AcademicMember.find({});

      const filteredAcademicMembers = allAcademicMembers.filter((e) => {
        return e.courseIds && e.courseIds.includes(req.body.courseId);
      });

      return res.status(200).json({
        academicMembers: filteredAcademicMembers,
      });

      return;
    }
    return res.status(401).json({
      error: "You don't have enough permission to perform this action",
    });
  } catch (error) {
    next(error);
  }
};
