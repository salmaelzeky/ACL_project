const AcademicMember = require('../models/AcademicMember');
const ReplacementRequest = require('../models/ReplacementRequest');
const Notification = require('../models/Notification');
const Slot = require('../models/Slot');

exports.viewReplacementRequests = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      let status = null;

      if (req.body.status) {
        status = req.body.status;
      }

      let requests = null;

      if (!status) {
        requests = await ReplacementRequest.find({
          $or: [{ receiverAcademicMemberId: req.id }, { senderAcademicMemberId: req.id }],
        });
      } else if (status === 'accepted') {
        requests = await ReplacementRequest.find({
          $or: [{ receiverAcademicMemberId: req.id }, { senderAcademicMemberId: req.id }],
          status: 'accepted',
        });
      } else if (status === 'rejected') {
        requests = await ReplacementRequest.find({
          $or: [{ receiverAcademicMemberId: req.id }, { senderAcademicMemberId: req.id }],
          status: 'rejected',
        });
      } else if (status === 'pending') {
        requests = await ReplacementRequest.find({
          $or: [{ receiverAcademicMemberId: req.id }, { senderAcademicMemberId: req.id }],
          status: 'pending',
        });
      } else {
        return res.status(401).json({
          error: 'Please enter a valid status',
        });
      }

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.sendReplacementRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const senderAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: senderAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      if (!req.body.date) {
        return res.status(405).json({
          error: 'please set a date',
        });
      }

      let date = new Date(req.body.date);

      if (date.toLocaleDateString() === 'Invalid Date') {
        return res.status(405).json({
          error: 'please set a date a right date',
        });
      }

      date.setDate(date.getDate() + 1);

      const { receiverAcademicMemberId, slotId } = req.body;
      const status = 'pending';

      const slot = await Slot.findById(slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'Slot does not exist',
        });
      }

      const newRequest = new ReplacementRequest({
        senderAcademicMemberId,
        receiverAcademicMemberId,
        slotId,
        status,
        date,
      });

      await newRequest.save();

      return res.status(200).json({
        request: newRequest,
        message: 'The request has been successfully made',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.acceptReplacementRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const receiverAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: receiverAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.replacementRequestId;
      const replacementRequest = await ReplacementRequest.findById(requestId);

      if (!replacementRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (receiverAcademicMemberId !== replacementRequest.receiverAcademicMemberId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (replacementRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot accept this request',
        });
      }

      let currentDate = new Date();

      if (replacementRequest.date > currentDate) {
        return res.status(401).json({
          error: 'You cannot accept a request after its time',
        });
      }

      await Slot.findByIdAndUpdate(replacementRequest.slotId, {
        substituteAcademicMemberId: receiverAcademicMemberId,
      });

      const academicMemberId = replacementRequest.senderAcademicMemberId;

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'replacement',
        status: 'accepted',
      });

      await newNotification.save();

      replacementRequest.status = 'accepted';

      await replacementRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully accepted',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.rejectReplacementRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const receiverAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: receiverAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.replacementRequestId;
      const replacementRequest = await ReplacementRequest.findById(requestId);

      if (!replacementRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (receiverAcademicMemberId !== replacementRequest.receiverAcademicMemberId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (replacementRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot reject this request',
        });
      }

      const academicMemberId = replacementRequest.senderAcademicMemberId;

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'replacement',
        status: 'rejected',
      });

      await newNotification.save();

      replacementRequest.status = 'rejected';

      await replacementRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully rejected',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.cancelReplacementRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const senderAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: senderAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.replacementRequestId;
      const replacementRequest = await ReplacementRequest.findById(requestId);

      if (!replacementRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (senderAcademicMemberId !== replacementRequest.senderAcademicMemberId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (replacementRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot cancel this request',
        });
      }

      await ReplacementRequest.findByIdAndDelete(requestId);

      return res.status(200).json({
        message: 'The request has been successfully cancelled',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};
