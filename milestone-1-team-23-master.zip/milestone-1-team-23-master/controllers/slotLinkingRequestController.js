const AcademicMember = require('../models/AcademicMember');
const Course = require('../models/Course');
const Slot = require('../models/Slot');
const Notification = require('../models/Notification');
const SlotLinkingRequest = require('../models/SlotLinkingRequest');

exports.sendSlotLinkingRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const { slotId } = req.body;
      const status = 'pending';

      const slot = await Slot.findById(slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'Slot does not exist',
        });
      }

      const course = await Course.findById(slot.courseId);

      if (!course) {
        return res.status(401).json({
          error: 'No course for this slot',
        });
      }

      const courseCoordinatorId = course.courseCoordinatorId;

      const newRequest = new SlotLinkingRequest({
        academicMemberId,
        courseCoordinatorId,
        slotId,
        status,
      });

      await newRequest.save();

      return res.status(200).json({
        request: newRequest,
        message: 'The request has been successfully made',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewSlotLinkingRequests = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      let status = null;

      if (req.body.status) {
        status = req.body.status;
      }

      let requests = null;

      if (!status) {
        requests = await SlotLinkingRequest.find({ academicMemberId: req.id });
      } else if (status === 'accepted') {
        requests = await SlotLinkingRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else if (status === 'rejected') {
        requests = await SlotLinkingRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else if (status === 'pending') {
        requests = await SlotLinkingRequest.find({
          academicMemberId: req.id,
          status,
        });
      } else {
        return res.status(401).json({
          error: 'Please enter a valid status',
        });
      }

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.cancelSlotLinkingRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const senderAcademicMemberId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: senderAcademicMemberId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.slotLinkingRequestId;
      const slotLinkingRequest = await SlotLinkingRequest.findById(requestId);

      if (!slotLinkingRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (senderAcademicMemberId !== slotLinkingRequest.academicMemberId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (slotLinkingRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot cancel this request',
        });
      }

      await SlotLinkingRequest.findByIdAndDelete(requestId);

      return res.status(200).json({
        message: 'The request has been successfully cancelled',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.viewSlotLinkingRequestsByCoordinator = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const academicMember = await AcademicMember.findOne({ uniId: req.id });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const course = await Course.findOne({ courseCoordinatorId: req.id });

      if (!course) {
        return res.status(401).json({
          error: 'You are not a coordinator in any course',
        });
      }

      const requests = await SlotLinkingRequest.find({
        courseCoordinatorId: req.id,
      });

      return res.status(200).json({
        requests: requests,
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.acceptSlotLinkingRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const courseCoordinatorId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: courseCoordinatorId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.slotLinkingRequestId;
      const slotLinkingRequest = await SlotLinkingRequest.findById(requestId);

      if (!slotLinkingRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (slotLinkingRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot accept this request',
        });
      }

      const slot = await Slot.findById(slotLinkingRequest.slotId);

      if (!slot) {
        return res.status(401).json({
          error: 'No Slot with that id',
        });
      }

      const course = await Course.findById(slot.courseId);

      if (!course) {
        return res.status(401).json({
          error: 'No course linked with this slot',
        });
      }

      if (slotLinkingRequest.courseCoordinatorId !== courseCoordinatorId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      const academicMemberId = slotLinkingRequest.academicMemberId;

      const assignedAcademicMember = await AcademicMember.findOne({
        uniId: academicMemberId,
      });

      if (!assignedAcademicMember) {
        return res.status(401).json({
          error: 'No academic member with that id',
        });
      }

      await Slot.findByIdAndUpdate(slotLinkingRequest.slotId, {
        academicMemberId,
      });

      if (!assignedAcademicMember.courseIds) {
        assignedAcademicMember.courseIds = [course._id];
      } else {
        assignedAcademicMember.courseIds.push(course._id);
      }

      await assignedAcademicMember.save();

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'slotLinking',
        status: 'accepted',
      });

      await newNotification.save();

      slotLinkingRequest.status = 'accepted';

      await slotLinkingRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully accepted',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};

exports.rejectSlotLinkingRequest = async (req, res, next) => {
  if (req.role !== 'hr') {
    try {
      const courseCoordinatorId = req.id;
      const academicMember = await AcademicMember.findOne({
        uniId: courseCoordinatorId,
      });

      if (!academicMember) {
        return res.status(401).json({
          error: 'Academic member does not exist',
        });
      }

      const requestId = req.params.slotLinkingRequestId;
      const slotLinkingRequest = await SlotLinkingRequest.findById(requestId);

      if (!slotLinkingRequest) {
        return res.status(401).json({
          error: 'No request with this id',
        });
      }

      if (slotLinkingRequest.courseCoordinatorId !== courseCoordinatorId) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }

      if (slotLinkingRequest.status !== 'pending') {
        return res.status(401).json({
          error: 'You cannot reject this request',
        });
      }

      const academicMemberId = slotLinkingRequest.academicMemberId;

      const newNotification = new Notification({
        academicMemberId,
        requestId,
        type: 'slotLinking',
        status: 'rejected',
      });

      await newNotification.save();

      slotLinkingRequest.status = 'rejected';

      await slotLinkingRequest.save();

      return res.status(200).json({
        message: 'The request has been successfully rejected',
      });
    } catch (error) {
      next(error);
    }
    return;
  }
  return res.status(401).json({
    error: "You don't have enough permission to perform this action",
  });
};
