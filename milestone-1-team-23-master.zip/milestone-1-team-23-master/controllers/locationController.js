const Location = require('../models/Location');

exports.getAllLocations = async (req, res, next) => {
  try {
    const allLocations = await Location.find({});

    return res.status(200).json({
      locations: allLocations,
    });
  } catch (error) {
    next(error);
  }
};

exports.addLocation = async (req, res, next) => {
  try {
    const { name, type, fullCapacity } = req.body;

    const newLocation = new Location({
      name,
      type,
      fullCapacity,
      currentCapacity: 0,
    });
    await newLocation.save();
    res.json({
      data: newLocation,
      message: 'The location has been created Successfully',
    });
  } catch (error) {
    next(error);
  }
};

exports.updateLocation = async (req, res, next) => {
  try {
    const locationId = req.params.locationId;
    const { name, type, fullCapacity, currentCapacity } = req.body;
    await Location.findByIdAndUpdate(
      locationId,
      { name, type, fullCapacity, currentCapacity },
      { omitUndefined: true }
    );
    const location = await Location.findById(locationId);
    return res.status(200).json({
      data: location,
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteLocation = async (req, res, next) => {
  try {
    const locationId = req.params.locationId;
    await Location.findByIdAndDelete(locationId);
    return res.status(200).json({
      data: null,
      message: 'Location has been deleted',
    });
  } catch (error) {
    next(error);
  }
};
